# APEX Recursive Discovery R1 — بستهٔ آزمایش بدون API و بدون هزینهٔ AI

**مهم‌ترین محدودیت:** این بسته یک موتور سادهٔ قانون‌محور و خواندنی است، نه هوش خودتکاملی و نه عامل درآمدزا.
اولین نمونه، **دو فرضیهٔ خلاف‌واقع، پرسش‌های فضای خالی، انتقادها و چک‌لیست شواهد** را از عنوان
یک مقالهٔ RSS موجود می‌سازد؛ و چون واقعاً اطلاعات بازار را بررسی نکرده، نتیجه را `BLOCKED_PENDING_EVIDENCE`
و ارتقای مدل را `REJECT` ثبت می‌کند.

## ساختار
- `PATCH_TO_EXISTING_BOOTSTRAP/core/apex/discovery/`: فقط افزودهٔ ماژول جدید؛ هیچ فایل قدیمی را جایگزین نمی‌کند.
- `PATCH_TO_EXISTING_BOOTSTRAP/tests/test_discovery.py`: آزمون واحد آفلاین.
- `PATCH_TO_EXISTING_BOOTSTRAP/scripts/run_discovery_once.sh`: اجرای یک‌باره پس از صحت سرویس Docker.
- `MANIFESTO_PRESERVED_LOCALLY/constitution.txt`: مانیفست کامل ۱۸بخشی بدون دستکاری.
- `MANIFESTO_PRESERVED_LOCALLY/constitution.sha256`: اثر انگشت بررسی اصالت.
- `DECISION_RECORD_FA.md`: تصمیم معماری برای گفتگوهای بعدی.

## گام ۱: آزمایش روی کامپیوتر توسعه، بدون نیاز به VPS/API/Docker
از پوشهٔ `PATCH_TO_EXISTING_BOOTSTRAP` در Python 3.10+:

```bash
PYTHONPATH=core python3 -m unittest discover -s tests -p test_discovery.py -v
PYTHONPATH=core python3 -m apex.discovery.cli --fixture
```

**توجه:** ورودی `--fixture` ساختگی و صریحاً علامت‌گذاری شده؛ اعتبارسنجی بازار واقعی نیست.

## گام ۲: استقرار بعدی روی VPS شخصی، فقط پس از گرفتن نسخهٔ پشتیبان و بررسی Docker
ماژول‌های `PATCH_TO_EXISTING_BOOTSTRAP` را به پوشهٔ فعلی
`/opt/apex/APEX_4_4_NIGHT1_PRIVATE_BOOTSTRAP/` منتقل کن؛
فایل‌های `compose.yaml`، `.env`، `core/apex/app.py`، جدول‌های پایگاه داده و Volumeها تغییر نمی‌کنند.

```bash
cd /opt/apex/APEX_4_4_NIGHT1_PRIVATE_BOOTSTRAP
docker compose ps
docker compose build core
docker compose up -d --no-deps core
bash scripts/run_discovery_once.sh
```

**این چهار دستور دستورالعمل آینده‌اند، نه اثبات اینکه هم‌اکنون روی VPS اجرا شده‌اند.**
ابتدا وضعیت سرویس‌ها و امن بودن سرور را بررسی کن. فایل `constitution.txt` را
صرفاً در پوشهٔ مرجع محلی نگه دار؛ آن را به API نفرست و اطلاعات حساس را در گزارش‌های عمومی درج نکن.

## دربارهٔ API key
- در این آزمایش هیچ کلید Claude/OpenAI لازم نیست، هیچ API فراخوانی نمی‌شود.
- `POSTGRES_PASSWORD` کلید API هوش مصنوعی نیست.
- اگر بعداً مدل فعال شد، از حساب شخصی با سقف هزینه و مجوزهای مشخص استفاده شود؛
  هرگز کلید را در چت، اسکرین‌شات، GitHub یا حساب شرکتی قرار نده.

## تعهد ضدادعای کاذب
- دو فرضیهٔ تولیدشده خودشان «کشف جدید» نیستند.
- نقدِ قانون‌محور، یک منتقد هوش مصنوعی مستقل نیست.
- ثبت خروجی JSON، یادگیری ماشینی یا انتخاب تکاملی واقعی نیست.
- هیچ آزمون برتری در برابر ChatGPT، Claude یا متخصص اجرا نشده است.
- برای این قابلیت‌ها باید در نسخه‌های بعد موتور LLM و ارزیابی بیرونی با مجوز و سقف هزینه اضافه شود.
